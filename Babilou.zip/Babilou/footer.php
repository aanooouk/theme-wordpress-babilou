    
    </div>
    <?php wp_footer() ?>

    <footer>
        <div class="footer-part1">
            <div class="icone-text">
                <img src="https://image.flaticon.com/icons/png/512/74/74577.png">
                <H5>A propos</H5>
            </div>

            <div class="icone-text">
                <img src="https://i.pinimg.com/originals/b2/c6/09/b2c6098c212e8e922e2366c51d517869.png">
                <H5>Agenda</H5>
            </div>

            <div class="icone-text">
                <img src="https://www.wambrechies.fr/sites/default/files/styles/full/public/field/image/faq_icon_noun_like.svg_.png?itok=9prWeYFI">
                <H5>FAQ</H5>
            </div>

            <div class="icone-text">
                <img src="https://www.pngkit.com/png/full/792-7920301_icone-jeu-png-icone-jeux-video-png.png">
                <H5>Jeux</H5>
            </div>

        </div>

 


        <div class="footer-part2">
            <div class="column-footer">
                <ul>
                    <li id="first-list"><a href="#">Votre CE</a></li>
                    <br>
                    <li><a href="#">A propos</a></li>
                    <li><a href="#">Agenda</a></li>

                </ul>

            </div>

            <div class="column-footer">
                <ul>
                    <li id="first-list"><a href="#">Ciné</a></li>
                    <br>
                    <li><a href="#">UGC</a></li>
                    <li><a href="#">Gaumont</a></li>

                </ul>

            </div>

            <div class="column-footer">
                <ul>
                    <li id="first-list"><a href="#">Parcs</a></li>
                    <br>
                    <li><a href="#">Disney</a></li>
                    <li><a href="#">Parc Astérix</a></li>

                </ul>

            </div>

            <div class="column-footer">
                <ul>
                    <li id="first-list"><a href="#">Voyages</a></li>
                    <br>
                    <li><a href="#">Club med</a></li>
                    <li><a href="#">Location</a></li>

                </ul>

            </div>

            <div class="column-footer">
                <ul>
                    <li id="first-list"><a href="#">Sport</a></li>
                    <br>
                    <li><a href="#">Piscine</a></li>
                    <li><a href="#">Pétanque (lol)</a></li>

                </ul>

            </div>

            <div class="column-footer">
                <ul>
                    <li id="first-list"><a href="#">Culture</a></li>
                    <br>
                    <li><a href="#">Musique</a></li>
                    <li><a href="#">Aquarium</a></li>

                </ul>

            </div>

            <div class="column-footer">
                <ul>
                    <li id="first-list"><a href="#">Produits</a></li>
                    <br>
                    <li><a href="#">Catalogue</a></li>
                    <li><a href="#">Achats intégrés</a></li>

                </ul>

            </div>

        </div>


        <div class="footer-part3">

            <p> Conception : Anouk Courant </p>
            <div class="footer-social">
                <a href="#"><img src="https://cdn.icon-icons.com/icons2/1099/PNG/512/1485482214-facebook_78681.png"></a>
        
                <a href="#"><img src="https://www.evs.fr/sites/all/themes/custom/evs2017/images/twitter.png"></a>
            
                <a href="#"><img src="https://cdn.clipart.email/3141c4809ddc026c5e1ee8c3a9caccdb_social-media-pinterest-square-free-icon-of-social-media-color-_512-512.png"></a>
            
            </div>

        </div>
        


    </footer>
</body>
</html>