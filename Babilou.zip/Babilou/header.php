<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head() ?>
</head>
<body>
    <div class="container-nav">

    <img class="logo" src="https://upload.wikimedia.org/wikipedia/commons/a/ab/Android_O_Preview_Logo.png" alt="logo">
        
    <?php wp_nav_menu(
        ['theme_location' => 'MAIN_MENU', 
        'container => false',
        'menu_class' => 'navbar-nav']) ?>
    
    <div class="social">
        <a href="#"><img src="https://www.stickpng.com/assets/images/584856bce0bb315b0f7675ad.png"></a>
        <a href="#"><img src="https://cdn0.iconfinder.com/data/icons/user-collection-4/512/user-512.png"></a>
        <a href="#"><img src="https://www.freeiconspng.com/uploads/exit-button-icon-18.png"></a>
    </div>
    
    </div>
    



